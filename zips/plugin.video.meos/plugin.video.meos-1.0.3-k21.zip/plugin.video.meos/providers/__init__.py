from .official_partner import OfficialPartnerProvider


def get_providers():
    return [
        OfficialPartnerProvider(),
    ]
