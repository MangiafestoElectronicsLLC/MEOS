from .base import BaseProvider


CATALOG = [
    {
        "media_id": "movie_big_buck_bunny",
        "title": "Big Buck Bunny",
        "category": "movies",
        "genre": "Animation",
        "stream_url": "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
        "mime_type": "application/vnd.apple.mpegurl",
    },
    {
        "media_id": "movie_elephants_dream",
        "title": "Elephants Dream",
        "category": "movies",
        "genre": "Animation",
        "stream_url": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "movie_sintel",
        "title": "Sintel",
        "category": "movies",
        "genre": "Animation",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "movie_tears_of_steel",
        "title": "Tears of Steel",
        "category": "movies",
        "genre": "Sci-Fi",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "tv_for_bigger_blazes",
        "title": "For Bigger Blazes",
        "category": "tv",
        "genre": "TV",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "tv_for_bigger_escape",
        "title": "For Bigger Escape",
        "category": "tv",
        "genre": "TV",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "tv_for_bigger_fun",
        "title": "For Bigger Fun",
        "category": "tv",
        "genre": "TV",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "tv_for_bigger_meltdowns",
        "title": "For Bigger Meltdowns",
        "category": "tv",
        "genre": "TV",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "tv_for_bigger_joyrides",
        "title": "For Bigger Joyrides",
        "category": "tv",
        "genre": "TV",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "docs_we_are_going_on_bullrun",
        "title": "We Are Going On Bullrun",
        "category": "docs",
        "genre": "Documentary",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "live_test_channel",
        "title": "MEOS Live Test Channel",
        "category": "live",
        "genre": "Live",
        "stream_url": "https://test-streams.mux.dev/test_001/stream.m3u8",
        "mime_type": "application/vnd.apple.mpegurl",
    },
    {
        "media_id": "sports_test_feed",
        "title": "MEOS Sports Test Feed",
        "category": "sports",
        "genre": "Sports",
        "stream_url": "https://test-streams.mux.dev/dai-discontinuity-deltatre/manifest.m3u8",
        "mime_type": "application/vnd.apple.mpegurl",
    },
    {
        "media_id": "sports_tears_of_steel_trailer",
        "title": "Sports Showcase Clip",
        "category": "sports",
        "genre": "Sports",
        "stream_url": "https://test-streams.mux.dev/pts_shift/master.m3u8",
        "mime_type": "application/vnd.apple.mpegurl",
    },
    {
        "media_id": "cable_test_channel",
        "title": "MEOS Cable Test Channel",
        "category": "cable",
        "genre": "Cable TV",
        "stream_url": "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
        "mime_type": "application/vnd.apple.mpegurl",
    },
    {
        "media_id": "ppv_test_event",
        "title": "MEOS PPV Test Event",
        "category": "ppv",
        "genre": "PPV",
        "stream_url": "https://test-streams.mux.dev/test_001/stream.m3u8",
        "mime_type": "application/vnd.apple.mpegurl",
    },
    {
        "media_id": "movie_subaru_outback_short",
        "title": "Subaru Outback On Street and Dirt",
        "category": "movies",
        "genre": "Automotive",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "movie_volkswagen_gti_review",
        "title": "Volkswagen GTI Review",
        "category": "movies",
        "genre": "Automotive",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "movie_what_car_for_a_grand",
        "title": "What Car Can You Get For A Grand?",
        "category": "movies",
        "genre": "Automotive",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "tv_google_blender_archive",
        "title": "Big Buck Bunny (Internet Archive Mirror)",
        "category": "tv",
        "genre": "Animation",
        "stream_url": "https://archive.org/download/BigBuckBunny_328/BigBuckBunny_512kb.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "tv_elephants_dream_archive",
        "title": "Elephants Dream (Internet Archive Mirror)",
        "category": "tv",
        "genre": "Animation",
        "stream_url": "https://archive.org/download/ElephantsDream/ed_1024_512kb.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "docs_for_bigger_escape",
        "title": "For Bigger Escapes",
        "category": "docs",
        "genre": "Short Film",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "docs_for_bigger_joyrides",
        "title": "For Bigger Joyrides",
        "category": "docs",
        "genre": "Short Film",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "docs_for_bigger_meltdowns",
        "title": "For Bigger Meltdowns",
        "category": "docs",
        "genre": "Short Film",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "sports_subaru_clip",
        "title": "Subaru Off-Road Showcase",
        "category": "sports",
        "genre": "Motorsport",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "sports_gti_clip",
        "title": "GTI Driving Showcase",
        "category": "sports",
        "genre": "Motorsport",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "cable_for_bigger_escape",
        "title": "Cable Demo: For Bigger Escapes",
        "category": "cable",
        "genre": "Cable TV",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "cable_for_bigger_fun",
        "title": "Cable Demo: For Bigger Fun",
        "category": "cable",
        "genre": "Cable TV",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "ppv_showcase_automotive",
        "title": "PPV Showcase: Performance Auto",
        "category": "ppv",
        "genre": "PPV",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4",
        "mime_type": "video/mp4",
    },
    {
        "media_id": "ppv_showcase_stunts",
        "title": "PPV Showcase: Stunt Highlight",
        "category": "ppv",
        "genre": "PPV",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
        "mime_type": "video/mp4",
    },
]


class OfficialPartnerProvider(BaseProvider):
    """
    MEOS Demo content provider.

    Provides a curated set of publicly accessible, royalty-free demo streams
    sourced from Google's sample media bucket and Mux test streams.
    All items are free and legal to stream.
    """

    id = "official_partner"
    name = "MEOS Demo"
    requires_oauth = False

    def start_device_authorization(self):
        return {
            "verification_uri": "https://www.mangiafestoelectronics.com/",
            "user_code": "MEOS-DEMO",
        }

    def get_catalog(self, auth_state, category=None, query=None, year=None, award=None, result=None):
        items = CATALOG

        if category and category != "award":
            items = [item for item in items if item.get("category") == category]

        if query:
            q = query.lower().strip()
            items = [item for item in items if q in item.get("title", "").lower()]

        return [{"media_id": item["media_id"], "title": item["title"], "genre": item["genre"]} for item in items]

    def check_entitlement(self, media_id, auth_state):
        return True, ""

    def resolve_playback(self, media_id, auth_state):
        selected = next((item for item in CATALOG if item["media_id"] == media_id), None)
        if not selected:
            return None

        return {
            "stream_url": selected["stream_url"],
            "title": selected["title"],
            "mime_type": selected.get("mime_type", ""),
            "license_url": "",
        }
