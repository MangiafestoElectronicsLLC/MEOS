from .base import BaseProvider


CATALOG = [
    {
        "media_id": "movie_big_buck_bunny",
        "title": "Movies: Big Buck Bunny",
        "genre": "Animation",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    },
    {
        "media_id": "movie_elephants_dream",
        "title": "Movies: Elephants Dream",
        "genre": "Animation",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
        "media_id": "tv_for_bigger_blazes",
        "title": "TV Shows: For Bigger Blazes",
        "genre": "Demo",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    },
    {
        "media_id": "tv_for_bigger_escape",
        "title": "TV Shows: For Bigger Escape",
        "genre": "Demo",
        "stream_url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    },
]


class OfficialPartnerProvider(BaseProvider):
    id = "official_partner"
    name = "Official Partner Demo"
    requires_oauth = True

    def start_device_authorization(self):
        return {
            "verification_uri": "https://www.mangiafestoelectronics.com/",
            "user_code": "MEOS-DEMO",
        }

    def get_catalog(self, auth_state):
        return [{"media_id": item["media_id"], "title": item["title"], "genre": item["genre"]} for item in CATALOG]

    def check_entitlement(self, media_id, auth_state):
        if auth_state != "connected":
            return False, "Connect account before playback"
        return True, ""

    def resolve_playback(self, media_id, auth_state):
        if auth_state != "connected":
            return None

        selected = next((item for item in CATALOG if item["media_id"] == media_id), None)
        if not selected:
            return None

        # Replace these with official playback endpoints from your licensed provider.
        return {
            "stream_url": selected["stream_url"],
            "license_url": "",
            "license_type": "com.widevine.alpha",
            "manifest_type": "mpd",
            "license_headers": "",
        }
