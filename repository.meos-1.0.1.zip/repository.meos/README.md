# MEOS
Streaming
For Use of any Streaming Device Mainly products I curate including MEOS, and MEOS Stick
Can Access my Company website @ https://www.mangiafestoelectronics.com/
Contact Me @ 585-227-4686 or Email Me @ 
ZacharyMangiafesto@MangiafestoElectronics.onmicrosoft.com

## Quick Start: Install And Test In Kodi

This repo now supports a repeatable build flow for Kodi testing.

If you only want one file to install in Kodi, use `MEOS_ADDON.zip`.

Build behavior:

- Default: every build auto-increments patch versions in both addon.xml files.
- Release-safe mode: use `-NoAutoBump` when you want to keep current versions unchanged.

### 1) Build fresh repository and addon zips

From PowerShell in this folder:

```powershell
./scripts/build-kodi-repo.ps1
```

To build without changing versions:

```powershell
./scripts/build-kodi-repo.ps1 -NoAutoBump
```

This regenerates:

- `MEOS_ADDON.zip` (single-file direct install)
- `KodiInstall/MEOS_ADDON.zip` (same file in a clean install folder)
- `KodiInstall/repository.meos.zip` (optional repository install path)
- `addons.xml`
- `addons.xml.md5`
- `zips/plugin.video.meos/plugin.video.meos-<version>.zip`
- `repository.meos-<version>.zip`
- `repository.meos.zip` (convenience copy)

### 2) Install to Kodi (fastest path)

Use this path if you want the same flow as other addons (single zip file):

1. In Kodi: Settings -> Add-ons -> Install from zip file.
2. Browse to `KodiInstall`.
3. Select `MEOS_ADDON.zip`.
4. Open Video add-ons -> MEOS Test.

Optional repository install path (not required):

1. Copy `repository.meos.zip` to your Kodi device.
2. In Kodi: Settings -> Add-ons -> Install from zip file.
3. Select `repository.meos.zip`.
4. Then go to Install from repository -> MEOS Repository -> Video add-ons -> MEOS Test -> Install.

If your Kodi build blocks repository browsing, use direct zip install:

1. Copy `zips/plugin.video.meos/plugin.video.meos-<version>.zip` to your Kodi device.
2. In Kodi: Settings -> Add-ons -> Install from zip file.
3. Select that plugin zip directly.

### 3) Validate playback

1. Open the `MEOS Test` addon from Video add-ons.
2. Select `Quick Test Stream`.
3. Confirm the sample stream starts and plays.

### 4) Official Partner Scaffold (Legal Integrations)

The addon now includes a legal provider scaffold with official-flow placeholders:

- OAuth device flow hook (`Connect account` action)
- Entitlement check hook before playback
- DRM hook (inputstream adaptive license properties)

Current provider stubs are in `repository.meos/providers/`:

- `official_partner.py` (licensed partner flow scaffold)
- `youtube_official.py` (official API setup placeholder)

This gives you a clean base to wire licensed providers without scraping or bypass behavior.

### 5) Troubleshooting

- If repository install fails, rebuild with `./scripts/build-kodi-repo.ps1` and retry with the new zip.
- If the addon installs but does not play, check Kodi logs and verify internet connectivity on device.
- For clean retests, uninstall `MEOS Repository` and `MEOS Test`, then reinstall from the new zip.

## First V1.0.0 Commit To GitHub

If you want a clean initial baseline at version 1.0.0:

1. Ensure addon versions are still 1.0.0 in both addon.xml files.
2. Run a no-bump build:

```powershell
./scripts/build-kodi-repo.ps1 -NoAutoBump
```

3. Commit and tag:

```powershell
git add .
git commit -m "chore: initial v1.0.0 kodi repo baseline"
git tag v1.0.0
git push origin main
git push origin v1.0.0
```

After this baseline, run normal builds (without -NoAutoBump) to auto-create 1.0.1, 1.0.2, and so on.

## Provider Integration Policy

This project should only integrate legal, free, and authorized providers. You can add:

- YouTube channels/playlists via official public feeds or APIs
- Public-domain catalogs
- Free ad-supported streams that explicitly allow third-party playback

Do not copy or reuse private scraping logic, paid-stream bypass logic, or unauthorized resolver logic from other addons.


# MEOS Firestick 4K Enhancement

Enhance your Amazon Firestick 4K with Manifesto Electronics' custom Kodi configuration and software. This software unlocks advanced streaming, gaming, and modular add-ons—already deployed and sold to satisfied customers.

## 🔧 Features
- Kodi-based media center with custom skins and plugins
- Retro gaming support via integrated emulators
- Modular add-ons for streaming, gaming, and accessibility

## 🛠️ Setup
1. Configure Wifi Settings
2. Go to Kodi App and check Preconfigured Favorites List 

## 🔀 Feature Toggles
- `ENABLE_ACCESSIBILITY_UI`: Activates large text and voice prompts

## 🗺️ Roadmap
- Q4 2025: Add voice control and ALS-friendly UI
- Q1 2026: Improve setup wizard for non-technical users

# MEOS Retro Console – Atari to PSP

A plug-and-play retro gaming console built on Raspberry Pi 3+ using RetroPie, EmulationStation, and Kodi. Supports Atari, NES, SNES, PSP, and many more.

## 🔧 Features
- EmulationStation frontend with custom themes and improved software
- Kodi integration for media playback
- Modular ROM packs and controller profiles

## 🛠️ Setup
1. Boot Pi and follow on-screen setup
2. Exit Kodi APP to Gaming Consoles to setup Wifi
3. Within Gaming console named setup allows Wifi settings
4. Reboot, Test Movie, Show, ETC 

## 🔀 Feature Toggles
- `ENABLE_KODI`: Launch Kodi on boot
- `ENABLE_GAMING`: Launch Gaming Consoles on boot

## 🗺️ Roadmap
- Q1 2026: Add online multiplayer support
- Q2 2026: Publish controller remapping tool
