# MEOS Hub

MEOS Hub is a single, all-in-one Kodi add-on that lets you browse, search
and play content from multiple sources - free/legal streams, metadata
scrapers, and your existing installed Kodi add-ons - **inside one unified
interface**, without switching between add-ons.

MEOS Hub never copies, bundles, or scrapes another add-on's source code. It
only uses Kodi's own JSON-RPC API to find add-ons you already have
installed and hand you a normal `plugin://` link into their menus
("routing"). Playback of MEOS Hub's own free/legal content uses the
standard `xbmcplugin.setResolvedUrl` API.

---

## 0. Installing MEOS Hub (Kodi 18.7 and Kodi 19+/20+)

MEOS Hub ships in two build profiles from the same source, produced by
`scripts/build-kodi-repo.ps1`:

| Kodi version | Zip | Install method |
| --- | --- | --- |
| 19+ / 20+ / Firestick (modern, Python 3) | `zips/plugin.video.meoshub/plugin.video.meoshub-<version>.zip` | Install the MEOS repository (`repository.meos.zip`), then **Add-ons -> Install from repository -> MEOS Repository -> MEOS Hub** (auto-updates), or install that zip directly. |
| 18.7 / Leia (legacy, Python 2) | `MEOS_HUB_K18.zip` | **Add-ons -> Install from zip file** directly. The repository's `addons.xml` only targets Kodi 19+, so Kodi 18.7 always needs this zip installed manually and reinstalled for updates. |

See the top-level [README.md](../README.md) for the full any-device
install walkthrough (GitHub Pages source vs. manual zip transfer). Both
build profiles are generated from this same `plugin.video.meoshub/`
source folder - the code itself is written to run under both Python 2
(Kodi 18.7) and Python 3 (Kodi 19+), only the `xbmc.python` dependency
version in the packaged `addon.xml` differs between the two zips.

---

## 0b. Source menus, genres, free content and holidays

Movies and TV Shows open a menu where you pick where content comes from:

- **TMDB** - Popular, Top Rated, Trending, Now Playing, or **Browse by genre** (needs your free TMDB key). Choosing a title searches the whole hub for it.
- **Free Movies / TV Shows** - public-domain titles from archive.org, by genre (no key, directly playable).
- **Free Channels (live)** - free live channels in the Movies / Series groups.
- **From your add-ons** - Ghost, Scrubs V2 and anything you integrate.
- **Holidays**.

**Live TV, Sports and Networks** gain **Free Live Channels** (News, Sports, Movies,
Kids, Music, Documentary, ...) loaded from public iptv-org playlists, plus
**My Playlist (M3U)** if you set your own M3U URL or file in Settings -> Scrapers.
The **Holidays** entry on the main menu (toggle it under Settings ->
Toggle Categories) lists Christmas, Halloween, Thanksgiving, Easter,
Valentine's Day, New Year's, Independence Day, St. Patrick's Day,
Hanukkah, Kwanzaa, Mother's/Father's Day, Memorial/Veterans Day, MLK Day
and Groundhog Day. Holidays that are in season today are listed first and
flagged on the main menu. Use **Search Holidays** (or the main Search) and
type any name or nickname ("xmas", "4th of july") to jump straight to it.

Genre and holiday pages combine: matching titles from your integrated
add-ons, free archive.org titles, and (with your own free TMDB API key)
popular TMDB titles - choosing a TMDB title searches the whole hub for it.

## 0c. Default integrations

Red Gratis, Ghost, The Loop, The Crew, Scrubs V2, Rising Tides and YouTube
are built in. A startup service (`service.py`) enables any that are installed
but disabled, and asks Kodi to install missing ones from the repositories you
already have (once each, no nagging). Retry anytime via Settings -> Manage
Integrations -> Install / refresh default add-ons; turn auto-install off in
the add-on settings. MEOS never bundles third-party code, so an add-on can
only be auto-installed if one of your repositories provides it. Add more with
"+ Add Your Own Add-on" or "Discover All Installed Add-ons".

---

## 1. How it works

```
default.py            -> Kodi calls this. It just forwards argv to router.py.
resources/lib/router.py -> Parses the plugin:// URL and calls one ui.py function.
resources/lib/ui.py      -> Builds every menu/list Kodi shows (ListItems).
resources/lib/integrations/ -> Finds + browses OTHER installed add-ons (routing only).
resources/lib/scrapers/     -> Free/legal metadata + stream sources (TMDB, archive.org, custom).
resources/lib/content/      -> Unified categories, favorites, search, import/export.
resources/lib/utils/        -> Small Kodi API wrappers (settings, JSON-RPC, cache, logging).
```

Folder layout:

```
plugin.video.meoshub/
  addon.xml
  default.py
  setup_dev.bat
  resources/
    settings.xml
    lib/
      router.py
      ui.py
      integrations/
        base.py           # Integration/IntegrationSpec classes
        known_addons.py   # Built-in specs: Scrubs V2, The Loop, Ghost, The Crew
        manager.py        # Resolves specs -> installed add-ons, merges categories
      scrapers/
        base.py           # MetadataScraper / StreamScraper interfaces
        tmdb_scraper.py   # TMDB metadata (needs a free user API key)
        archive_org_scraper.py  # Public-domain streams via archive.org
        custom_scraper.py # Generic JSON-API scraper driven by a URL template
        manager.py        # Registry of enabled scrapers
      content/
        categories.py     # Unified category list + toggles
        browse.py         # Genre + holiday definitions and result gathering
        favorites.py       # Favorites persistence (JSON in settings)
        search.py          # Unified search across all of the above
        importexport.py    # CSV/XLSX import, JSON export
      utils/
        kodi.py, jsonrpc.py, cache.py, settings.py
  tools/
    test_harness.py    # Offline validation + smoke tests (no Kodi required)
    kodi_mocks.py       # Fake xbmc*/xbmcgui/xbmcplugin/xbmcaddon/xbmcvfs modules
```

### Main menu

`Movies | TV Shows | Networks | Sports | PPV | Live TV / Cable | Addon
Integrations | Search | Favorites | Settings`

Each unified category page shows:
- A "Search free public-domain ..." shortcut (archive.org), when enabled.
- Merged listings pulled live from every installed/enabled integration
  (each item is prefixed `[Add-on Name]` so you always know its source).

### Addon Integrations menu

Lists **Scrubs V2**, **The Loop**, **Ghost**, **The Crew**, plus **+ Add
Your Own Add-on** and **Discover All Installed Add-ons**. Each shows
whether it's currently installed on this device. Selecting an installed
integration opens its own unified Movies/TV Shows/.../Live TV categories
*inside MEOS Hub*; selecting an item routes straight into that add-on's
own `plugin://` URL, exactly like opening it directly - MEOS Hub does not
need to understand its internal code to do this.

**Discover All Installed Add-ons** lists every other video add-on already
installed on the device (found via `Addons.GetAddons`) and lets you flip
any of them into an integration with a single select - no need to type an
add-on id. Discovered add-ons don't need a hand-written path mapping: MEOS
Hub falls back to a bounded breadth-first scan of the add-on's own menu
tree, scoring folder labels against generic category keywords (see
`CATEGORY_KEYWORDS` in `known_addons.py`), and caches whatever folder it
resolves so repeat visits are fast. This is what makes MEOS Hub a true
"any and all add-ons" hub instead of a curated allow-list.

---

## 2. Adding a new integrated add-on

You do **not** need to edit any code to add an add-on. Two ways:

1. **Fastest:** open **Addon Integrations -> Discover All Installed
   Add-ons** and select the add-on from the list of everything already
   installed on this device.
2. **Manual:** go to **Addon Integrations -> + Add Your Own Add-on** (or
   **Settings -> Manage Integrations -> + Add Your Own Add-on**) and enter
   the exact add-on id (e.g. `plugin.video.example`) - find this in
   Kodi's *Add-ons -> My add-ons -> ... -> Information* screen.

Either way, MEOS Hub will browse that add-on's own menu tree looking for
folders named things like "Movies", "TV Shows", "Live TV", etc. and merge
whatever it finds into the matching MEOS Hub category. If the add-on
uses different wording, its content still shows up as a folder shortcut
you can browse manually inside **Addon Integrations**.

If you *are* editing code (e.g. to contribute a better path mapping for a
popular add-on), add an entry to `BUILTIN_INTEGRATIONS` in
`resources/lib/integrations/known_addons.py`:

```python
{
    'key': 'myaddon',
    'label': 'My Add-on',
    'addon_id_guess': 'plugin.video.myaddon',
    'keywords': ['myaddon', 'my add-on'],   # used for fuzzy matching if the id differs
    'category_paths': {
        'movies': [['Movies'], ['Movies', 'Movies']],
        'tvshows': [['TV Shows']],
        ...
    },
},
```
and add a matching bool setting + `BUILTIN_TOGGLE_SETTING` entry if you
want it individually toggleable like the four required integrations.

## 3. Adding a new scraper

**Without writing code:** go to **Settings -> Manage Scrapers -> + Add
Custom Scraper**, give it a name and a URL template containing `{query}`.
The endpoint must return a JSON array (or `{"results": [...]}` /
`{"items": [...]}`) of objects with any of these common field names:
`title`/`name`, `url`/`link`/`stream`, `poster`/`thumb`/`image`,
`plot`/`description`, `year`/`date`.

**With code:** subclass `MetadataScraper` or `StreamScraper` in
`resources/lib/scrapers/base.py`, implement `search(self, query)`, and
register it in `resources/lib/scrapers/manager.py`'s
`get_metadata_scrapers()` / `get_stream_scrapers()`.

## 4. Customizing menus

- **Toggle categories:** Settings -> Toggle Categories (or the native Kodi
  add-on settings screen under "Categories").
- **UI theme:** Settings -> Change UI Theme (Default/Dark/Light).
- **Category -> integration path mapping:** edit `category_paths` in
  `known_addons.py`, or use **+ Add Your Own Add-on** which relies on
  automatic folder-name matching.

## 5. Import / Export

- **Import** (Settings -> Import/Export -> Import Content Sources):
  accepts a CSV or simple single-sheet XLSX file with header row
  `title,category,type,value`, where `type` is `addon` (value = an add-on
  id to integrate) or `stream` (value = a direct playable URL, saved to
  Favorites).
- **Export**: writes JSON files (`meoshub_integrations.json`,
  `meoshub_scrapers.json`, `meoshub_favorites.json`) to the folder set in
  Settings -> Import/Export folder (default `special://temp/meoshub_exports`).

## 6. Testing

Run the offline test harness any time, no Kodi installation required:

```
python tools/test_harness.py
```

It validates `addon.xml`/`settings.xml`, byte-compiles every `.py` file,
and smoke-tests the router against every core screen using lightweight
mocks of the Kodi Python API (`tools/kodi_mocks.py`).

## 7. Dev automation script

```
setup_dev.bat            REM validate only
setup_dev.bat launch     REM validate, install into %APPDATA%\Kodi\addons, launch Kodi --debug, open kodi.log
setup_dev.bat logs       REM just open the current kodi.log
```

Set the `KODI_HOME` environment variable first if your Kodi userdata
folder isn't the default `%APPDATA%\Kodi`.

## 8. Notes on legality and scope

MEOS Hub only ships code that talks to official/public APIs
(archive.org's public metadata API, the official TMDB API using your own
free key) and routes into add-ons the user has chosen to install
separately. It does not include, scrape, or proxy any unlicensed
streaming sources.
